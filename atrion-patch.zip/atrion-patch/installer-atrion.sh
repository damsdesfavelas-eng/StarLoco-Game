#!/usr/bin/env bash
# Installe le patch Atrion (prestige) dans starloco-docker puis reconstruit le serveur.
# Usage (Git Bash) :  bash installer-atrion.sh
set -e
HERE="$(cd "$(dirname "$0")" && pwd)"
TARGET="$HOME/starloco-docker"
[ -d "$TARGET/game" ] || { echo "Dossier $TARGET introuvable"; exit 1; }

echo "== Patch Atrion version 2026-11-19g (deplacement auto carte par carte, potions x2)"
echo "== Copie des fichiers Atrion"
rm -rf "$TARGET/game/atrion"
cp -r "$HERE/atrion" "$TARGET/game/atrion"

DF="$TARGET/game/Dockerfile"
if ! grep -q "ATRION" "$DF"; then
  echo "== Modification du Dockerfile (sauvegarde : Dockerfile.orig)"
  cp "$DF" "$DF.orig"
  awk '/^COPY entrypoint.sh/ && !done {
         print "# ATRION : serveur modifie (prestige)";
         print "COPY atrion/game.jar /app/game.jar";
         print "COPY atrion/scripts/ /app/scripts/";
         print "RUN chown -R starloco:starloco /app";
         done=1 }
       { print }' "$DF.orig" > "$DF"
else
  echo "== Dockerfile deja modifie"
fi

ENVF="$TARGET/.env"
if [ -f "$ENVF" ] && ! grep -q "ATRION_RATES" "$ENVF"; then
  echo "== Taux Atrion : XP x3, drop x2, kamas x2, metiers x5 (modifiables dans .env)"
  sed -i 's/^RATE_XP=.*/RATE_XP=3/; s/^RATE_DROP=.*/RATE_DROP=2/; s/^RATE_KAMAS=.*/RATE_KAMAS=2/; s/^RATE_JOB=.*/RATE_JOB=5/' "$ENVF"
  echo "# ATRION_RATES (taux deja appliques par le patch)" >> "$ENVF"
fi

echo "== Reconstruction et redemarrage du serveur"
cd "$TARGET"
./run.sh start --build
echo
echo "Termine. Attends ~1 minute que le serveur de jeu charge, puis connecte-toi."
